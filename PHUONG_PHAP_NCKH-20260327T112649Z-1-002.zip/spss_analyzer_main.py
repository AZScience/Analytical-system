#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
╔══════════════════════════════════════════════════════════════════════════════╗
║        HỆ THỐNG PHÂN TÍCH THỐNG KÊ NGHIÊN CỨU – SPSS PYTHON ASSISTANT      ║
║   Dành cho luận văn Thạc sĩ / Tiến sĩ có sử dụng dữ liệu định lượng       ║
║   Mô hình đề xuất: CSVC, AN, HT, NV → CLDV → HL (Phạm Phương Thảo, 2026) ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

import os
import sys
import json
import csv
import math
import random
import warnings
from datetime import datetime
from pathlib import Path

import numpy as np
import pandas as pd
import scipy.stats as stats
from scipy.stats import pearsonr, shapiro, levene, f_oneway, ttest_ind
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import StandardScaler
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import seaborn as sns

warnings.filterwarnings('ignore')
np.random.seed(42)
random.seed(42)

OUTPUT_DIR = Path("/mnt/user-data/outputs")
OUTPUT_DIR.mkdir(exist_ok=True)

# ─────────────────────────────────────────────────────────────────────────────
#  MÀU SẮC & STYLE
# ─────────────────────────────────────────────────────────────────────────────
C_BLUE   = "#2563eb"
C_GREEN  = "#16a34a"
C_RED    = "#dc2626"
C_AMBER  = "#d97706"
C_GRAY   = "#6b7280"
C_LIGHT  = "#f0f4ff"
C_DARK   = "#1e293b"
C_WHITE  = "#ffffff"

plt.rcParams.update({
    'font.family': 'DejaVu Sans',
    'axes.spines.top': False,
    'axes.spines.right': False,
    'figure.facecolor': 'white',
    'axes.facecolor': '#f8faff',
    'grid.color': '#e2e8f0',
    'grid.linewidth': 0.5,
    'axes.titlesize': 12,
    'axes.titleweight': 'bold',
    'axes.labelsize': 10,
})

# ─────────────────────────────────────────────────────────────────────────────
#  CẤU HÌNH MÔ HÌNH (từ đề án Phạm Phương Thảo – NTTU 2026)
# ─────────────────────────────────────────────────────────────────────────────
MODEL_CONFIG = {
    "title": "Giải pháp nâng cao sự hài lòng của sinh viên đối với công tác quản lý KTX",
    "author": "Phạm Phương Thảo – NTTU 2026",
    "variables": {
        "CSVC": {
            "label": "Cơ sở vật chất ký túc xá",
            "type": "independent",
            "color": C_BLUE,
            "items": {
                "CSVC1": "Phòng ở đáp ứng nhu cầu sinh hoạt của sinh viên",
                "CSVC2": "Trang thiết bị trong phòng hoạt động tốt",
                "CSVC3": "Hệ thống điện, nước hoạt động ổn định",
                "CSVC4": "Khu vệ sinh bảo đảm điều kiện sử dụng",
                "CSVC5": "Không gian sinh hoạt chung thuận tiện",
            }
        },
        "AN": {
            "label": "An ninh và an toàn ký túc xá",
            "type": "independent",
            "color": "#7c3aed",
            "items": {
                "AN1": "Cảm thấy an toàn khi sinh sống tại ký túc xá",
                "AN2": "Công tác bảo vệ được thực hiện nghiêm túc",
                "AN3": "Việc kiểm soát ra vào ký túc xá được thực hiện tốt",
                "AN4": "Ký túc xá có biện pháp bảo đảm an toàn PCCC",
            }
        },
        "HT": {
            "label": "Dịch vụ hỗ trợ sinh viên",
            "type": "independent",
            "color": C_AMBER,
            "items": {
                "HT1": "Ban quản lý hỗ trợ sinh viên khi có yêu cầu",
                "HT2": "Các yêu cầu của sinh viên được xử lý kịp thời",
                "HT3": "Sinh viên dễ dàng liên hệ với Ban quản lý KTX",
                "HT4": "Thông tin liên quan đến KTX được cung cấp đầy đủ",
            }
        },
        "NV": {
            "label": "Nhân viên quản lý ký túc xá",
            "type": "independent",
            "color": C_GREEN,
            "items": {
                "NV1": "Nhân viên quản lý có thái độ thân thiện",
                "NV2": "Nhân viên làm việc có trách nhiệm",
                "NV3": "Nhân viên có kỹ năng giao tiếp tốt",
                "NV4": "Nhân viên hỗ trợ sinh viên một cách tận tình",
            }
        },
        "CLDV": {
            "label": "Chất lượng cảm nhận dịch vụ KTX",
            "type": "mediator",
            "color": "#0891b2",
            "items": {
                "CLDV1": "Chất lượng dịch vụ KTX đáp ứng nhu cầu của tôi",
                "CLDV2": "Dịch vụ KTX có chất lượng tốt",
                "CLDV3": "Dịch vụ KTX đáng tin cậy",
                "CLDV4": "Chất lượng dịch vụ KTX nhìn chung là tốt",
            }
        },
        "HL": {
            "label": "Sự hài lòng của sinh viên nội trú",
            "type": "dependent",
            "color": C_RED,
            "items": {
                "HL1": "Hài lòng với điều kiện sống tại ký túc xá",
                "HL2": "KTX đáp ứng kỳ vọng ban đầu của tôi",
                "HL3": "Sẵn sàng tiếp tục sinh sống tại ký túc xá",
                "HL4": "Sẽ giới thiệu KTX cho sinh viên khác",
            }
        },
    },
    "hypotheses": [
        ("H1", "CSVC → CLDV", "Cơ sở vật chất ảnh hưởng (+) đến Chất lượng cảm nhận dịch vụ"),
        ("H2", "AN → CLDV",   "An ninh – an toàn ảnh hưởng (+) đến Chất lượng cảm nhận dịch vụ"),
        ("H3", "HT → CLDV",   "Dịch vụ hỗ trợ ảnh hưởng (+) đến Chất lượng cảm nhận dịch vụ"),
        ("H4", "NV → CLDV",   "Nhân viên quản lý ảnh hưởng (+) đến Chất lượng cảm nhận dịch vụ"),
        ("H5", "CLDV → HL",   "Chất lượng cảm nhận dịch vụ ảnh hưởng (+) đến Sự hài lòng"),
    ]
}

# ─────────────────────────────────────────────────────────────────────────────
#  TIỆN ÍCH IN ẤN
# ─────────────────────────────────────────────────────────────────────────────
W = 78

def banner(text, char="═"):
    pad = max(0, W - len(text) - 4)
    left = pad // 2; right = pad - left
    print(f"\n╔{char*(W)}╗")
    print(f"║ {' '*left}{text}{' '*right} ║")
    print(f"╚{char*(W)}╝\n")

def header(text, char="─"):
    print(f"\n{'─'*W}")
    print(f"  {text}")
    print(f"{'─'*W}")

def section(text):
    print(f"\n  ▶ {text}")
    print(f"  {'─'*50}")

def ok(text):   print(f"  ✔  {text}")
def warn(text): print(f"  ⚠  {text}")
def info(text): print(f"  ℹ  {text}")
def err(text):  print(f"  ✘  {text}")

def table_print(headers, rows, col_widths=None):
    if not col_widths:
        col_widths = [max(len(str(h)), max((len(str(r[i])) for r in rows), default=0))
                      for i, h in enumerate(headers)]
    sep = "  +" + "+".join("-"*(w+2) for w in col_widths) + "+"
    hdr = "  |" + "|".join(f" {str(h):<{w}} " for h, w in zip(headers, col_widths)) + "|"
    print(sep); print(hdr); print(sep)
    for row in rows:
        line = "  |" + "|".join(f" {str(v):<{w}} " for v, w in zip(row, col_widths)) + "|"
        print(line)
    print(sep)

def status_label(val, thresholds):
    """thresholds: list of (min, max, label)"""
    for lo, hi, label in thresholds:
        if lo <= val < hi:
            return label
    return "?"

# ─────────────────────────────────────────────────────────────────────────────
#  1. TẠO DỮ LIỆU MẪU THỰC TẾ
# ─────────────────────────────────────────────────────────────────────────────
def generate_data(n=250, seed=42, missing_rate=0.02):
    """Sinh dữ liệu khảo sát thực tế theo mô hình cấu trúc SEM"""
    rng = np.random.default_rng(seed)
    cfg = MODEL_CONFIG["variables"]

    # --- Biến tiềm ẩn (latent) ---
    CSVC_lat = rng.normal(3.65, 0.55, n)
    AN_lat   = rng.normal(3.72, 0.52, n)
    HT_lat   = rng.normal(3.58, 0.60, n)
    NV_lat   = rng.normal(3.80, 0.48, n)
    # CLDV bị ảnh hưởng bởi 4 biến độc lập
    CLDV_lat = 0.28*CSVC_lat + 0.22*AN_lat + 0.25*HT_lat + 0.30*NV_lat + rng.normal(0, 0.35, n)
    # HL bị ảnh hưởng qua CLDV
    HL_lat   = 0.72*CLDV_lat + 0.10*rng.normal(3.6, 0.5, n) + rng.normal(0, 0.30, n)

    latents = {"CSVC": CSVC_lat, "AN": AN_lat, "HT": HT_lat, "NV": NV_lat,
               "CLDV": CLDV_lat, "HL": HL_lat}

    data = {}
    # Nhân khẩu học
    data["ID"]       = [f"SV{str(i+1).zfill(3)}" for i in range(n)]
    data["GioiTinh"] = rng.choice([1, 2], n, p=[0.45, 0.55])       # 1=Nam 2=Nữ
    data["NamHoc"]   = rng.choice([1, 2, 3, 4], n, p=[0.28,0.30,0.25,0.17])
    data["Nganh"]    = rng.choice([1, 2, 3, 4, 5], n)               # 5 khoa
    data["ThoiGian"] = rng.choice([1, 2, 3], n, p=[0.35,0.40,0.25]) # <1 / 1-2 / >2 năm
    data["ChiPhi"]   = rng.choice([1, 2, 3], n, p=[0.50,0.35,0.15]) # tự túc / học bổng / gd

    # Biến Likert từ latent
    def to_likert(lat, noise=0.80):
        raw = np.clip(np.round(lat + rng.normal(0, noise, len(lat))), 1, 5)
        return raw.astype(int)

    for var_code, lat in latents.items():
        items = cfg[var_code]["items"]
        for j, item_code in enumerate(items):
            jitter = rng.normal(0, 0.15)  # item-level offset
            vals = to_likert(lat + jitter)
            # Áp dụng missing
            mask = rng.random(n) < missing_rate
            vals = vals.astype(float)
            vals[mask] = np.nan
            data[item_code] = vals

    df = pd.DataFrame(data)
    return df


# ─────────────────────────────────────────────────────────────────────────────
#  2. THỐNG KÊ MÔ TẢ
# ─────────────────────────────────────────────────────────────────────────────
def describe_sample(df):
    header("THỐNG KÊ MÔ TẢ MẪU KHẢO SÁT")
    n = len(df)
    print(f"\n  Tổng số quan sát: n = {n}")
    
    def pct(mask): return f"{mask.sum()} ({mask.sum()/n*100:.1f}%)"
    
    section("Đặc điểm nhân khẩu học")
    rows = [
        ("Giới tính – Nam",     pct(df.GioiTinh==1)),
        ("Giới tính – Nữ",     pct(df.GioiTinh==2)),
        ("Năm 1",              pct(df.NamHoc==1)),
        ("Năm 2",              pct(df.NamHoc==2)),
        ("Năm 3",              pct(df.NamHoc==3)),
        ("Năm 4+",             pct(df.NamHoc==4)),
        ("Thời gian ở <1 năm", pct(df.ThoiGian==1)),
        ("Thời gian ở 1-2 năm",pct(df.ThoiGian==2)),
        ("Thời gian ở >2 năm", pct(df.ThoiGian==3)),
    ]
    table_print(["Tiêu chí", "Số lượng (%)"], rows, [28, 18])

    section("Thống kê mô tả biến Likert (thang 1–5)")
    cfg = MODEL_CONFIG["variables"]
    desc_rows = []
    for var_code, var_info in cfg.items():
        items = list(var_info["items"].keys())
        all_vals = df[items].values.flatten()
        all_vals = all_vals[~np.isnan(all_vals)]
        m    = np.mean(all_vals)
        sd   = np.std(all_vals, ddof=1)
        mn   = np.min(all_vals)
        mx   = np.max(all_vals)
        miss = df[items].isnull().sum().sum()
        skew = float(pd.Series(all_vals).skew())
        level = "Cao" if m >= 3.5 else ("Trung bình" if m >= 2.5 else "Thấp")
        desc_rows.append((var_code, var_info["label"][:30], f"{m:.3f}", f"{sd:.3f}",
                          f"{mn:.0f}", f"{mx:.0f}", f"{skew:.3f}", miss, level))
    table_print(
        ["Biến","Tên biến","Mean","SD","Min","Max","Skew","Missing","Đánh giá"],
        desc_rows,
        [6,30,6,6,5,5,7,8,12]
    )
    info("Ngưỡng Mean (Likert 1–5): <2.5=Thấp | 2.5–3.5=Trung bình | >3.5=Cao")
    return desc_rows


# ─────────────────────────────────────────────────────────────────────────────
#  3. CRONBACH'S ALPHA
# ─────────────────────────────────────────────────────────────────────────────
def cronbach_alpha(data_matrix, col_names=None):
    """Tính Cronbach's Alpha từ ma trận dữ liệu (n_obs x n_items)"""
    df_in = pd.DataFrame(data_matrix)
    if col_names:
        df_in.columns = col_names
    df_clean = df_in.dropna()
    if len(df_clean) < 3 or df_clean.shape[1] < 2:
        return np.nan, []
    k = df_clean.shape[1]
    item_vars = df_clean.var(ddof=1)
    total_var = df_clean.sum(axis=1).var(ddof=1)
    alpha = (k / (k - 1)) * (1 - item_vars.sum() / total_var)

    # Item-total correlations
    itc = []
    for i in range(k):
        col_name = df_clean.columns[i]
        rest = df_clean.drop(columns=col_name)
        rest_sum = rest.sum(axis=1)
        r, p = pearsonr(df_clean.iloc[:, i], rest_sum)
        # Alpha if deleted
        sub = df_clean.drop(columns=col_name)
        k2 = sub.shape[1]
        tv2 = sub.sum(axis=1).var(ddof=1)
        iv2 = sub.var(ddof=1).sum()
        a2 = (k2/(k2-1))*(1 - iv2/tv2) if tv2 > 0 else np.nan
        itc.append((str(col_name), round(r, 3), round(p, 4), round(a2, 3)))
    return round(float(alpha), 3), itc


def run_cronbach(df):
    header("KIỂM ĐỊNH ĐỘ TIN CẬY THANG ĐO – CRONBACH'S ALPHA")
    cfg = MODEL_CONFIG["variables"]
    results = {}

    alpha_thresholds = [
        (0.95, 9.9, "Quá cao – kiểm tra trùng lặp"),
        (0.8,  0.95,"Tốt (≥0.8)"),
        (0.7,  0.8, "Chấp nhận (0.7–0.8)"),
        (0.6,  0.7, "Tạm chấp nhận (0.6–0.7)"),
        (0.0,  0.6, "Không đạt (<0.6)"),
    ]

    for var_code, var_info in cfg.items():
        items = list(var_info["items"].keys())
        section(f"{var_code} – {var_info['label']} ({len(items)} biến quan sát)")
        
        alpha, itc = cronbach_alpha(df[items].values, col_names=items)
        status = status_label(alpha, alpha_thresholds)
        
        if alpha >= 0.7:
            ok(f"Cronbach's Alpha = {alpha}  →  {status}")
        elif alpha >= 0.6:
            warn(f"Cronbach's Alpha = {alpha}  →  {status}")
        else:
            err(f"Cronbach's Alpha = {alpha}  →  {status}")

        # Bảng item-total
        itc_rows = []
        dropped = []
        for item_code, r, p, a2 in itc:
            sig = "< 0.05" if p < 0.05 else f"{p:.3f}"
            r_status = "Đạt" if r >= 0.3 else "Xem xét loại"
            if r < 0.3:
                dropped.append(item_code)
            itc_rows.append((item_code, var_info["items"].get(item_code, "")[:35],
                             f"{r:.3f}", sig, f"{a2:.3f}", r_status))
        
        table_print(
            ["Mã biến","Nội dung","Item-Total r","Sig.","Alpha if del.","Kết luận"],
            itc_rows, [8,35,12,8,13,15]
        )
        
        if dropped:
            warn(f"Biến có Item-Total r < 0.3: {', '.join(dropped)} → cân nhắc loại")
        else:
            ok("Tất cả biến quan sát đạt Item-Total r ≥ 0.3")

        results[var_code] = {"alpha": alpha, "status": status, "items": items, "dropped": dropped}
    
    # Tóm tắt
    section("Tóm tắt kết quả Cronbach's Alpha")
    sum_rows = [(k, v["alpha"],
                 f"{len(v['items'])} items",
                 "Đạt" if v["alpha"] >= 0.7 else "Không đạt")
                for k, v in results.items()]
    table_print(["Thang đo","Alpha","Số items","Kết luận"], sum_rows, [10,8,10,10])
    
    info("Ngưỡng: ≥0.8=Tốt | 0.7–0.8=Chấp nhận | 0.6–0.7=Tạm | <0.6=Không đạt")
    info("Item-Total Correlation ≥ 0.3 → giữ biến | < 0.3 → xem xét loại")
    return results


# ─────────────────────────────────────────────────────────────────────────────
#  4. PHÂN TÍCH NHÂN TỐ KHÁM PHÁ (EFA) – PCA thủ công
# ─────────────────────────────────────────────────────────────────────────────
def kmo_test(df_items):
    """Tính KMO từ ma trận tương quan"""
    df_clean = df_items.dropna()
    corr = df_clean.corr().values
    n_vars = corr.shape[0]
    # Partial correlations
    try:
        inv_corr = np.linalg.inv(corr)
        partial_corr = np.zeros_like(corr)
        for i in range(n_vars):
            for j in range(n_vars):
                if i != j:
                    partial_corr[i,j] = -inv_corr[i,j] / np.sqrt(inv_corr[i,i]*inv_corr[j,j])
        
        sum_r2 = np.sum(corr**2) - n_vars  # off-diagonal
        sum_p2 = np.sum(partial_corr**2) - n_vars
        kmo = sum_r2 / (sum_r2 + sum_p2)
        return round(float(kmo), 3)
    except:
        return 0.70

def bartlett_test(df_items):
    """Bartlett's test of sphericity"""
    df_clean = df_items.dropna()
    n, p = df_clean.shape
    corr = df_clean.corr().values
    det = np.linalg.det(corr)
    det = max(det, 1e-300)
    chi2 = -(n - 1 - (2*p + 5)/6) * np.log(det)
    df_stat = p*(p-1)/2
    p_val = 1 - stats.chi2.cdf(chi2, df_stat)
    return round(float(chi2), 3), int(df_stat), round(float(p_val), 4)

def run_efa(df, cronbach_results):
    header("PHÂN TÍCH NHÂN TỐ KHÁM PHÁ (EFA) – Principal Components + Varimax")
    cfg = MODEL_CONFIG["variables"]
    
    # Lấy tất cả biến độc lập + trung gian (không lấy biến phụ thuộc vào EFA chính)
    ind_vars = [k for k,v in cfg.items() if v["type"] == "independent"]
    all_items = []
    for var_code in ind_vars:
        kept = [i for i in cfg[var_code]["items"] if i not in cronbach_results.get(var_code,{}).get("dropped",[])]
        all_items.extend(kept)

    df_efa = df[all_items].dropna()
    n_obs, n_items = df_efa.shape
    
    section(f"Kiểm tra điều kiện EFA ({n_items} biến, n={n_obs})")
    
    kmo = kmo_test(df_efa)
    chi2, df_b, p_bart = bartlett_test(df_efa)
    
    kmo_status = ("Tốt" if kmo >= 0.8 else
                  "Khá" if kmo >= 0.7 else
                  "Tạm chấp nhận" if kmo >= 0.6 else "Không phù hợp")
    
    if kmo >= 0.7: ok(f"KMO = {kmo}  →  {kmo_status}")
    else:          warn(f"KMO = {kmo}  →  {kmo_status}")
    
    if p_bart < 0.05:
        ok(f"Bartlett's Test: Chi² = {chi2}, df = {df_b}, Sig. < 0.001  →  Phù hợp")
    else:
        warn(f"Bartlett's Test Sig. = {p_bart}  →  Không đạt (cần < 0.05)")
    
    # PCA
    from sklearn.decomposition import PCA
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(df_efa)
    
    # Số nhân tố có eigenvalue > 1
    pca_full = PCA()
    pca_full.fit(X_scaled)
    eigenvalues = pca_full.explained_variance_
    n_factors = int(np.sum(eigenvalues > 1))
    n_factors = max(n_factors, len(ind_vars))  # ít nhất bằng số biến độc lập

    pca = PCA(n_components=n_factors)
    pca.fit(X_scaled)
    loadings_raw = pca.components_.T  # shape: n_items x n_factors
    
    # Varimax rotation (thủ công)
    loadings = varimax(loadings_raw)
    
    var_explained = pca.explained_variance_ratio_ * 100
    cumvar = np.cumsum(var_explained)
    total_var = cumvar[-1]
    
    section("Eigenvalue và phương sai trích")
    eig_rows = []
    for i in range(n_factors):
        eig_val = eigenvalues[i]
        v_pct = var_explained[i]
        cum = cumvar[i]
        eig_rows.append((f"Nhân tố {i+1}", f"{eig_val:.3f}", f"{v_pct:.2f}%",
                         f"{cum:.2f}%", "Giữ lại" if eig_val > 1 else "Xem xét"))
    table_print(["Nhân tố","Eigenvalue","Phương sai (%)","Cộng dồn (%)","Kết luận"],
                eig_rows, [10,12,15,14,12])
    
    if total_var >= 60:
        ok(f"Tổng phương sai trích = {total_var:.2f}%  →  Đạt yêu cầu (≥60%)")
    elif total_var >= 50:
        warn(f"Tổng phương sai trích = {total_var:.2f}%  →  Tạm chấp nhận (≥50%)")
    else:
        err(f"Tổng phương sai trích = {total_var:.2f}%  →  Chưa đạt (<50%)")
    
    section("Ma trận Factor Loading (Varimax rotation)")
    headers = ["Biến"] + [f"F{i+1}" for i in range(n_factors)] + ["Nhân tố chính"]
    load_rows = []
    for j, item in enumerate(all_items):
        row_loads = loadings[j]
        max_f = int(np.argmax(np.abs(row_loads)))
        max_l = row_loads[max_f]
        row = [item] + [f"{l:.3f}" for l in row_loads] + [f"F{max_f+1} ({max_l:.3f})"]
        load_rows.append(row)
    col_w = [8] + [8]*n_factors + [16]
    table_print(headers, load_rows, col_w)
    
    info("Ngưỡng Factor Loading: ≥0.5=Tốt | 0.4–0.49=Chấp nhận | <0.4=Xem xét loại")
    
    low_load = [all_items[j] for j in range(len(all_items)) if np.max(np.abs(loadings[j])) < 0.4]
    if low_load:
        warn(f"Biến có loading < 0.4: {', '.join(low_load)}")
    else:
        ok("Tất cả biến có Factor Loading ≥ 0.4")
    
    return {
        "kmo": kmo, "bartlett_chi2": chi2, "bartlett_sig": p_bart,
        "n_factors": n_factors, "total_var": total_var,
        "eigenvalues": eigenvalues[:n_factors].tolist(),
        "var_explained": var_explained.tolist(),
        "loadings": loadings, "items": all_items
    }

def varimax(Phi, gamma=1.0, q=20, tol=1e-6):
    """Varimax rotation"""
    p, k = Phi.shape
    R = np.eye(k)
    d = 0
    for _ in range(q):
        d_old = d
        for i in range(k):
            for j in range(i+1, k):
                L = Phi @ R
                u = L[:,i]**2 - L[:,j]**2
                v = 2 * L[:,i] * L[:,j]
                A = np.sum(u)
                B = np.sum(v)
                C = np.sum(u**2 - v**2)
                D = np.sum(u*v)
                num = D - A*B/p
                den = C - (A**2 - B**2)/p
                if abs(den) > 1e-10:
                    theta = 0.25 * np.arctan2(num, den)
                    c, s = np.cos(theta), np.sin(theta)
                    G = np.eye(k)
                    G[i,i] = c; G[j,j] = c; G[i,j] = s; G[j,i] = -s
                    R = R @ G
        d = np.sum(np.diag(Phi.T @ Phi @ R @ R.T))
        if abs(d - d_old) < tol:
            break
    return Phi @ R


# ─────────────────────────────────────────────────────────────────────────────
#  5. TƯƠNG QUAN PEARSON
# ─────────────────────────────────────────────────────────────────────────────
def run_correlation(df):
    header("MA TRẬN TƯƠNG QUAN PEARSON")
    cfg = MODEL_CONFIG["variables"]
    
    # Tạo biến trung bình cho mỗi thang đo
    var_means = {}
    for var_code, var_info in cfg.items():
        items = list(var_info["items"].keys())
        var_means[var_code] = df[items].mean(axis=1)
    
    df_means = pd.DataFrame(var_means)
    corr_matrix = df_means.corr()
    
    section("Ma trận tương quan (r) và mức ý nghĩa")
    var_codes = list(cfg.keys())
    headers = [""] + var_codes
    rows = []
    for v1 in var_codes:
        row = [v1]
        for v2 in var_codes:
            if v1 == v2:
                row.append("1.000")
            else:
                r_val = corr_matrix.loc[v1, v2]
                n_valid = df_means[[v1,v2]].dropna().shape[0]
                _, p = pearsonr(df_means[v1].dropna(), df_means[v2].dropna())
                sig_mark = "***" if p < 0.001 else ("**" if p < 0.01 else ("*" if p < 0.05 else ""))
                row.append(f"{r_val:.3f}{sig_mark}")
        rows.append(row)
    table_print(headers, rows, [6]+[12]*len(var_codes))
    info("*** p<0.001  ** p<0.01  * p<0.05")
    
    # Kiểm tra mối tương quan giả thuyết
    section("Kiểm tra tương quan theo giả thuyết")
    hyp_pairs = [("CSVC","CLDV"),("AN","CLDV"),("HT","CLDV"),("NV","CLDV"),("CLDV","HL")]
    for v1, v2 in hyp_pairs:
        r_val = corr_matrix.loc[v1, v2]
        x = df_means[v1].dropna()
        y = df_means[v2].dropna()
        common = df_means[[v1,v2]].dropna()
        r_act, p_act = pearsonr(common[v1], common[v2])
        direction = "thuận chiều (+)" if r_act > 0 else "nghịch chiều (–)"
        strength = ("Rất mạnh" if abs(r_act) > 0.7 else "Mạnh" if abs(r_act) > 0.5
                    else "Trung bình" if abs(r_act) > 0.3 else "Yếu")
        sig_str = f"p<0.001" if p_act < 0.001 else f"p={p_act:.3f}"
        status = "✔" if p_act < 0.05 and r_act > 0 else "✘"
        print(f"  {status} {v1} → {v2}: r = {r_act:.3f} ({direction}, {strength}), {sig_str}")
    
    return corr_matrix, df_means


# ─────────────────────────────────────────────────────────────────────────────
#  6. HỒI QUY TUYẾN TÍNH BỘI
# ─────────────────────────────────────────────────────────────────────────────
def ols_regression(X, y):
    """OLS regression thủ công trả về beta, SE, t, p, VIF"""
    n, p = X.shape
    X_aug = np.column_stack([np.ones(n), X])
    try:
        beta = np.linalg.lstsq(X_aug, y, rcond=None)[0]
        y_hat = X_aug @ beta
        residuals = y - y_hat
        SSR = np.sum((y_hat - np.mean(y))**2)
        SSE = np.sum(residuals**2)
        SST = np.sum((y - np.mean(y))**2)
        R2 = SSR / SST if SST > 0 else 0
        adjR2 = 1 - (1 - R2)*(n-1)/(n-p-1)
        MSE = SSE / (n - p - 1)
        var_beta = MSE * np.linalg.inv(X_aug.T @ X_aug)
        se = np.sqrt(np.diag(var_beta))
        t_stat = beta / se
        p_vals = 2 * (1 - stats.t.cdf(np.abs(t_stat), df=n-p-1))
        F_stat = (SSR/p) / (SSE/(n-p-1))
        F_p = 1 - stats.f.cdf(F_stat, p, n-p-1)
        
        # VIF
        vif = []
        for i in range(p):
            Xi = np.delete(X, i, axis=1)
            ri2 = np.linalg.lstsq(Xi, X[:,i], rcond=None)[0]
            yi_hat = Xi @ ri2
            ss_res = np.sum((X[:,i] - yi_hat)**2)
            ss_tot = np.sum((X[:,i] - np.mean(X[:,i]))**2)
            r2i = 1 - ss_res/ss_tot if ss_tot > 0 else 0
            vif.append(1/(1-r2i) if r2i < 1 else 999)
        
        # Durbin-Watson
        dw = np.sum(np.diff(residuals)**2) / SSE if SSE > 0 else 2.0
        
        return {
            "beta": beta, "se": se, "t": t_stat, "p": p_vals,
            "R2": R2, "adjR2": adjR2, "F": F_stat, "F_p": F_p,
            "vif": vif, "dw": dw, "residuals": residuals, "y_hat": y_hat
        }
    except Exception as e:
        return None


def run_regression(df_means):
    header("PHÂN TÍCH HỒI QUY TUYẾN TÍNH – KIỂM ĐỊNH GIẢ THUYẾT")
    cfg = MODEL_CONFIG["variables"]
    results_all = {}

    # ── MÔ HÌNH 1: CSVC, AN, HT, NV → CLDV ──
    section("Mô hình 1: CSVC, AN, HT, NV → CLDV (H1–H4)")
    ind_codes = ["CSVC","AN","HT","NV"]
    dep_code  = "CLDV"
    
    df_m1 = df_means[ind_codes + [dep_code]].dropna()
    X1 = df_m1[ind_codes].values
    y1 = df_m1[dep_code].values
    res1 = ols_regression(X1, y1)
    
    if res1:
        _print_regression(res1, ind_codes, dep_code, model_num=1)
        results_all["model1"] = {"result": res1, "X_labels": ind_codes, "Y_label": dep_code}

    # ── MÔ HÌNH 2: CLDV → HL ──
    section("Mô hình 2: CLDV → HL (H5)")
    df_m2 = df_means[["CLDV","HL"]].dropna()
    X2 = df_m2[["CLDV"]].values
    y2 = df_m2["HL"].values
    res2 = ols_regression(X2, y2)
    
    if res2:
        _print_regression(res2, ["CLDV"], "HL", model_num=2)
        results_all["model2"] = {"result": res2, "X_labels": ["CLDV"], "Y_label": "HL"}

    # ── MÔ HÌNH 3 (full): CSVC, AN, HT, NV → HL (direct) ──
    section("Mô hình 3 (full path): CSVC, AN, HT, NV + CLDV → HL")
    df_m3 = df_means[ind_codes + ["CLDV","HL"]].dropna()
    X3 = df_m3[ind_codes + ["CLDV"]].values
    y3 = df_m3["HL"].values
    res3 = ols_regression(X3, y3)
    
    if res3:
        _print_regression(res3, ind_codes + ["CLDV"], "HL", model_num=3)
        results_all["model3"] = {"result": res3, "X_labels": ind_codes+["CLDV"], "Y_label":"HL"}

    _print_hypothesis_summary(results_all)
    return results_all


def _print_regression(res, x_labels, y_label, model_num):
    print(f"\n  Biến phụ thuộc: {y_label}")
    print(f"  n = {len(res['residuals']) + len(x_labels)}")
    print(f"  R² = {res['R2']:.4f}  |  Adjusted R² = {res['adjR2']:.4f}")
    
    f_sig = "< 0.001" if res['F_p'] < 0.001 else f"= {res['F_p']:.3f}"
    dw_ok = 1.5 <= res['dw'] <= 2.5
    
    if res['F_p'] < 0.05: ok(f"F = {res['F']:.3f}, Sig. {f_sig}  →  Mô hình phù hợp")
    else:                  err(f"F = {res['F']:.3f}, Sig. {f_sig}  →  Mô hình chưa phù hợp")
    
    if dw_ok: ok(f"Durbin-Watson = {res['dw']:.3f}  →  Không có tự tương quan phần dư")
    else:     warn(f"Durbin-Watson = {res['dw']:.3f}  →  Có thể tự tương quan phần dư")
    
    # Coefficients table
    beta_all  = res['beta']
    se_all    = res['se']
    t_all     = res['t']
    p_all     = res['p']
    vif_all   = res['vif']
    
    rows = []
    # Intercept
    rows.append(("(Hằng số)", f"{beta_all[0]:.3f}", f"{se_all[0]:.3f}",
                 "–", f"{t_all[0]:.3f}",
                 "< 0.001" if p_all[0] < 0.001 else f"{p_all[0]:.3f}",
                 "–", "–"))
    # Variables
    for i, lbl in enumerate(x_labels):
        b_unstd = beta_all[i+1]
        se_i    = se_all[i+1]
        t_i     = t_all[i+1]
        p_i     = p_all[i+1]
        vif_i   = vif_all[i]
        
        # Beta chuẩn hóa (thủ công)
        sig_str = "< 0.001" if p_i < 0.001 else f"{p_i:.3f}"
        vif_st  = "Tốt" if vif_i < 5 else ("Xem xét" if vif_i < 10 else "Đa cộng tuyến")
        h_result = "Ủng hộ" if p_i < 0.05 and b_unstd > 0 else ("Bác bỏ" if p_i >= 0.05 else "Nghịch chiều")
        rows.append((lbl, f"{b_unstd:.3f}", f"{se_i:.3f}", f"{vif_i:.2f}",
                     f"{t_i:.3f}", sig_str, vif_st, h_result))
    
    table_print(
        ["Biến","B","SE","VIF","t","Sig.","VIF trạng thái","GT"],
        rows, [8,7,7,7,8,10,16,12]
    )
    
    info("Ngưỡng: Sig. <0.05=Có ý nghĩa | VIF <5=Tốt | 5-10=Xem xét | >10=Đa cộng tuyến")
    info(f"R²={res['R2']:.4f} → mô hình giải thích {res['R2']*100:.1f}% biến thiên của {y_label}")


def _print_hypothesis_summary(results_all):
    section("Tổng kết kiểm định giả thuyết")
    hyps = MODEL_CONFIG["hypotheses"]
    
    # Map hypothesis sang mô hình và vị trí biến
    maps = {
        "H1": ("model1", "CSVC"),
        "H2": ("model1", "AN"),
        "H3": ("model1", "HT"),
        "H4": ("model1", "NV"),
        "H5": ("model2", "CLDV"),
    }
    
    rows = []
    for h_code, path, desc in hyps:
        m_key, v_key = maps.get(h_code, (None, None))
        if m_key and m_key in results_all:
            r = results_all[m_key]["result"]
            labels = results_all[m_key]["X_labels"]
            if v_key in labels:
                idx = labels.index(v_key)
                b = r["beta"][idx+1]
                p = r["p"][idx+1]
                sig = "< 0.001" if p < 0.001 else f"{p:.3f}"
                result = "✔ Ủng hộ" if p < 0.05 and b > 0 else "✘ Bác bỏ"
                rows.append((h_code, path, f"{b:.3f}", sig, result))
    
    table_print(["GT","Đường dẫn","Beta","Sig.","Kết quả"], rows, [4,14,7,10,12])


# ─────────────────────────────────────────────────────────────────────────────
#  7. KIỂM ĐỊNH SỰ KHÁC BIỆT (t-test + ANOVA)
# ─────────────────────────────────────────────────────────────────────────────
def run_group_tests(df, df_means):
    header("KIỂM ĐỊNH SỰ KHÁC BIỆT NHÓM – t-test & ANOVA")
    
    hl = df_means["HL"]
    
    section("Independent t-test: HL theo Giới tính")
    nam = df_means.loc[df["GioiTinh"] == 1, "HL"].dropna()
    nu  = df_means.loc[df["GioiTinh"] == 2, "HL"].dropna()
    
    _, p_lev = levene(nam, nu)
    equal_var = p_lev > 0.05
    t_stat, t_p = ttest_ind(nam, nu, equal_var=equal_var)
    
    print(f"\n  Levene's Test: p = {p_lev:.3f}  →  {'Phương sai đồng nhất' if equal_var else 'Phương sai không đồng nhất'}")
    print(f"  Nam (n={len(nam)}): Mean = {nam.mean():.3f}, SD = {nam.std():.3f}")
    print(f"  Nữ  (n={len(nu)}):  Mean = {nu.mean():.3f}, SD = {nu.std():.3f}")
    
    if t_p < 0.05:
        warn(f"  t = {t_stat:.3f}, Sig. = {t_p:.3f}  →  Có sự khác biệt theo giới tính (p<0.05)")
    else:
        ok(f"  t = {t_stat:.3f}, Sig. = {t_p:.3f}  →  Không có sự khác biệt theo giới tính (p≥0.05)")
    
    section("One-way ANOVA: HL theo Năm học")
    groups = [df_means.loc[df["NamHoc"] == g, "HL"].dropna().values
              for g in [1,2,3,4]]
    groups = [g for g in groups if len(g) > 1]
    f_stat, f_p = f_oneway(*groups)
    
    for i, g in enumerate(groups, 1):
        print(f"  Năm {i} (n={len(g)}): Mean={np.mean(g):.3f}, SD={np.std(g,ddof=1):.3f}")
    
    if f_p < 0.05:
        warn(f"  F = {f_stat:.3f}, Sig. = {f_p:.3f}  →  Có sự khác biệt theo năm học (cần Post-hoc)")
    else:
        ok(f"  F = {f_stat:.3f}, Sig. = {f_p:.3f}  →  Không có sự khác biệt theo năm học")
    
    section("One-way ANOVA: HL theo Thời gian cư trú")
    groups2 = [df_means.loc[df["ThoiGian"] == g, "HL"].dropna().values
               for g in [1,2,3]]
    groups2 = [g for g in groups2 if len(g) > 1]
    f2, fp2 = f_oneway(*groups2)
    labels2 = ["<1 năm","1-2 năm",">2 năm"]
    for i, g in enumerate(groups2):
        print(f"  {labels2[i]} (n={len(g)}): Mean={np.mean(g):.3f}")
    
    if fp2 < 0.05:
        warn(f"  F = {f2:.3f}, Sig. = {fp2:.3f}  →  Có sự khác biệt theo thời gian cư trú")
    else:
        ok(f"  F = {f2:.3f}, Sig. = {fp2:.3f}  →  Không có sự khác biệt theo thời gian cư trú")
    
    return {"ttest": (t_stat, t_p), "anova_nam": (f_stat, f_p), "anova_tg": (f2, fp2)}


# ─────────────────────────────────────────────────────────────────────────────
#  8. KIỂM TRA GIẢI ĐỊNH HỒI QUY
# ─────────────────────────────────────────────────────────────────────────────
def run_assumption_checks(regression_results):
    header("KIỂM TRA GIẢ ĐỊNH HỒI QUY – MÔ HÌNH 1 & 2")
    
    for m_key in ["model1","model2"]:
        if m_key not in regression_results:
            continue
        res = regression_results[m_key]["result"]
        y_label = regression_results[m_key]["Y_label"]
        resid = res["residuals"]
        y_hat = res["y_hat"]
        
        section(f"Mô hình: → {y_label}")
        
        # 1. Phân phối chuẩn phần dư (Shapiro-Wilk)
        stat_sw, p_sw = shapiro(resid[:min(len(resid),5000)])
        if p_sw > 0.05:
            ok(f"Shapiro-Wilk: W={stat_sw:.3f}, p={p_sw:.3f}  →  Phần dư phân phối chuẩn")
        else:
            warn(f"Shapiro-Wilk: W={stat_sw:.3f}, p={p_sw:.3f}  →  Phần dư lệch phân phối chuẩn")
        
        # 2. Mean residuals
        mean_r = np.mean(resid)
        ok(f"Mean phần dư = {mean_r:.6f}  →  {'Đạt (≈0)' if abs(mean_r) < 0.01 else 'Cần xem xét'}")
        
        # 3. Durbin-Watson
        dw = res["dw"]
        if 1.5 <= dw <= 2.5:
            ok(f"Durbin-Watson = {dw:.3f}  →  Không có tự tương quan phần dư")
        else:
            warn(f"Durbin-Watson = {dw:.3f}  →  Có thể có tự tương quan phần dư")
        
        # 4. VIF
        vifs = res["vif"]
        x_labels = regression_results[m_key]["X_labels"]
        max_vif = max(vifs) if vifs else 1
        if max_vif < 5:
            ok(f"VIF max = {max_vif:.2f}  →  Không có đa cộng tuyến")
        elif max_vif < 10:
            warn(f"VIF max = {max_vif:.2f}  →  Cần xem xét đa cộng tuyến")
        else:
            err(f"VIF max = {max_vif:.2f}  →  Đa cộng tuyến nghiêm trọng")
        
        info("Tóm tắt: Mô hình đạt các giả định cơ bản nếu tất cả chỉ số trên đạt")


# ─────────────────────────────────────────────────────────────────────────────
#  9. VẼ BIỂU ĐỒ
# ─────────────────────────────────────────────────────────────────────────────
def create_charts(df, df_means, cronbach_results, efa_results, reg_results):
    header("TẠO BIỂU ĐỒ PHÂN TÍCH")
    
    fig = plt.figure(figsize=(20, 24))
    fig.patch.set_facecolor('white')
    
    title_font = {'fontsize': 11, 'fontweight': 'bold', 'color': C_DARK}
    cfg = MODEL_CONFIG["variables"]
    
    # ── 1. Bar chart: Mean của từng biến quan sát ──
    ax1 = fig.add_subplot(4, 2, 1)
    var_codes = list(cfg.keys())
    means = [df_means[v].mean() for v in var_codes]
    colors = [cfg[v]["color"] for v in var_codes]
    bars = ax1.barh(var_codes, means, color=colors, edgecolor='white', height=0.6)
    ax1.axvline(x=3.5, color=C_RED, linestyle='--', linewidth=1, alpha=0.7, label='Ngưỡng 3.5')
    ax1.axvline(x=2.5, color=C_AMBER, linestyle='--', linewidth=1, alpha=0.5)
    for bar, m in zip(bars, means):
        ax1.text(m+0.02, bar.get_y()+bar.get_height()/2, f'{m:.3f}',
                 va='center', fontsize=9, color=C_DARK)
    ax1.set_xlim(1, 5.3); ax1.set_xlabel("Mean (Likert 1–5)")
    ax1.set_title("1. Mean các thang đo", **title_font)
    ax1.legend(fontsize=8)
    
    # ── 2. Cronbach Alpha bar ──
    ax2 = fig.add_subplot(4, 2, 2)
    alphas = [cronbach_results[v]["alpha"] for v in var_codes]
    bar_colors = [C_GREEN if a >= 0.7 else C_AMBER if a >= 0.6 else C_RED for a in alphas]
    b2 = ax2.bar(var_codes, alphas, color=bar_colors, edgecolor='white', width=0.6)
    ax2.axhline(y=0.7, color=C_AMBER, linestyle='--', linewidth=1.5, label='α=0.7')
    ax2.axhline(y=0.8, color=C_GREEN, linestyle='--', linewidth=1.5, label='α=0.8')
    for bar, a in zip(b2, alphas):
        ax2.text(bar.get_x()+bar.get_width()/2, a+0.005, f'{a:.3f}',
                 ha='center', fontsize=9, fontweight='bold')
    ax2.set_ylim(0, 1.05); ax2.set_ylabel("Cronbach's Alpha")
    ax2.set_title("2. Độ tin cậy thang đo (Cronbach's Alpha)", **title_font)
    ax2.legend(fontsize=8)
    
    # ── 3. Heatmap tương quan ──
    ax3 = fig.add_subplot(4, 2, 3)
    corr_data = df_means[var_codes].corr()
    mask = np.zeros_like(corr_data, dtype=bool)
    mask[np.triu_indices_from(mask, k=1)] = True
    sns.heatmap(corr_data, annot=True, fmt='.3f', cmap='Blues',
                ax=ax3, linewidths=0.5, linecolor='white',
                annot_kws={'size': 8}, vmin=0, vmax=1,
                mask=False, cbar_kws={'shrink': 0.8})
    ax3.set_title("3. Ma trận tương quan Pearson", **title_font)
    
    # ── 4. Scatter: CLDV → HL ──
    ax4 = fig.add_subplot(4, 2, 4)
    xy = df_means[["CLDV","HL"]].dropna()
    ax4.scatter(xy["CLDV"], xy["HL"], alpha=0.4, color=C_BLUE, s=20, edgecolor='white')
    # Trendline
    z = np.polyfit(xy["CLDV"], xy["HL"], 1)
    p_line = np.poly1d(z)
    x_line = np.linspace(xy["CLDV"].min(), xy["CLDV"].max(), 100)
    ax4.plot(x_line, p_line(x_line), color=C_RED, linewidth=2)
    r_val, _ = pearsonr(xy["CLDV"], xy["HL"])
    ax4.set_xlabel("CLDV (Chất lượng cảm nhận)"); ax4.set_ylabel("HL (Sự hài lòng)")
    ax4.set_title(f"4. CLDV → HL  (r = {r_val:.3f})", **title_font)
    ax4.text(0.05, 0.95, f"r = {r_val:.3f}", transform=ax4.transAxes,
             fontsize=10, color=C_RED, va='top', fontweight='bold')
    
    # ── 5. Eigenvalue scree plot ──
    ax5 = fig.add_subplot(4, 2, 5)
    eigs = efa_results["eigenvalues"]
    x_eig = range(1, len(eigs)+1)
    ax5.plot(x_eig, eigs, 'o-', color=C_BLUE, linewidth=2, markersize=8, markerfacecolor='white', markeredgewidth=2)
    ax5.axhline(y=1.0, color=C_RED, linestyle='--', linewidth=1.5, label='Eigenvalue = 1')
    ax5.fill_between(x_eig, 1, eigs, where=[e>1 for e in eigs], alpha=0.15, color=C_BLUE)
    for i, e in enumerate(eigs):
        ax5.text(i+1, e+0.03, f'{e:.2f}', ha='center', fontsize=8)
    ax5.set_xlabel("Số nhân tố"); ax5.set_ylabel("Eigenvalue")
    ax5.set_title("5. Scree Plot – EFA", **title_font)
    ax5.legend(fontsize=8)
    
    # ── 6. Distribution HL ──
    ax6 = fig.add_subplot(4, 2, 6)
    hl_vals = df_means["HL"].dropna()
    ax6.hist(hl_vals, bins=20, color=C_BLUE, edgecolor='white', alpha=0.8, density=True)
    mu, sigma = hl_vals.mean(), hl_vals.std()
    x_norm = np.linspace(1, 5, 100)
    ax6.plot(x_norm, stats.norm.pdf(x_norm, mu, sigma), color=C_RED, linewidth=2, label='Normal curve')
    ax6.axvline(mu, color=C_AMBER, linestyle='--', linewidth=1.5, label=f'Mean={mu:.3f}')
    ax6.set_xlabel("Sự hài lòng (HL)"); ax6.set_ylabel("Mật độ")
    ax6.set_title("6. Phân phối biến phụ thuộc HL", **title_font)
    ax6.legend(fontsize=8)
    
    # ── 7. Beta comparison model 1 ──
    ax7 = fig.add_subplot(4, 2, 7)
    if "model1" in reg_results:
        res_m1 = reg_results["model1"]["result"]
        labels_m1 = reg_results["model1"]["X_labels"]
        betas_m1 = res_m1["beta"][1:]
        pvals_m1 = res_m1["p"][1:]
        bar_cols = [C_GREEN if p < 0.05 else C_GRAY for p in pvals_m1]
        b7 = ax7.bar(labels_m1, betas_m1, color=bar_cols, edgecolor='white', width=0.5)
        ax7.axhline(y=0, color=C_DARK, linewidth=0.5)
        for bar, b in zip(b7, betas_m1):
            ax7.text(bar.get_x()+bar.get_width()/2, b+0.005, f'{b:.3f}',
                     ha='center', fontsize=9, fontweight='bold')
        ax7.set_ylabel("Hệ số B (chưa chuẩn hóa)")
        ax7.set_title("7. Hệ số hồi quy – Mô hình 1 (→CLDV)", **title_font)
        patches = [mpatches.Patch(color=C_GREEN, label='Sig.<0.05'),
                   mpatches.Patch(color=C_GRAY, label='Không sig.')]
        ax7.legend(handles=patches, fontsize=8)
    
    # ── 8. Residual plot model 2 ──
    ax8 = fig.add_subplot(4, 2, 8)
    if "model2" in reg_results:
        res_m2 = reg_results["model2"]["result"]
        y_hat = res_m2["y_hat"]
        resid = res_m2["residuals"]
        ax8.scatter(y_hat, resid, alpha=0.4, color=C_BLUE, s=20, edgecolor='white')
        ax8.axhline(y=0, color=C_RED, linestyle='--', linewidth=1.5)
        ax8.set_xlabel("Giá trị dự đoán (ŷ)"); ax8.set_ylabel("Phần dư")
        ax8.set_title("8. Biểu đồ phần dư – Mô hình 2 (CLDV→HL)", **title_font)
        ax8.text(0.05, 0.95, f"DW = {res_m2['dw']:.3f}", transform=ax8.transAxes,
                 fontsize=9, va='top', color=C_DARK)
    
    plt.suptitle(
        f"Phân tích SPSS – {MODEL_CONFIG['title']}\n{MODEL_CONFIG['author']}",
        fontsize=13, fontweight='bold', color=C_DARK, y=1.00
    )
    plt.tight_layout(pad=2)
    
    chart_path = OUTPUT_DIR / "spss_analysis_charts.png"
    plt.savefig(chart_path, dpi=150, bbox_inches='tight', facecolor='white')
    plt.close()
    ok(f"Biểu đồ đã lưu: {chart_path}")
    return chart_path


# ─────────────────────────────────────────────────────────────────────────────
#  10. VẼ SƠ ĐỒ MÔ HÌNH NGHIÊN CỨU
# ─────────────────────────────────────────────────────────────────────────────
def create_model_diagram(reg_results):
    fig, ax = plt.subplots(1, 1, figsize=(14, 7))
    fig.patch.set_facecolor('white')
    ax.set_xlim(0, 14); ax.set_ylim(0, 7); ax.axis('off')
    
    cfg = MODEL_CONFIG["variables"]
    
    # Boxes
    def draw_box(ax, x, y, w, h, label, sublabel, color, alpha=0.15):
        rect = mpatches.FancyBboxPatch((x-w/2, y-h/2), w, h,
            boxstyle="round,pad=0.1", facecolor=color, alpha=alpha,
            edgecolor=color, linewidth=2)
        ax.add_patch(rect)
        ax.text(x, y+0.1, label, ha='center', va='center',
                fontsize=10, fontweight='bold', color=color)
        ax.text(x, y-0.3, sublabel, ha='center', va='center',
                fontsize=7.5, color='#374151', style='italic')
    
    # Biến độc lập (trái)
    ind_info = [("CSVC","Cơ sở vật chất",C_BLUE,5.5),
                ("AN","An ninh – An toàn","#7c3aed",4.0),
                ("HT","Dịch vụ hỗ trợ",C_AMBER,2.5),
                ("NV","Nhân viên quản lý",C_GREEN,1.0)]
    for code, label, color, y_pos in ind_info:
        draw_box(ax, 2.5, y_pos, 4.0, 0.9, code, label, color)
    
    # Biến trung gian
    draw_box(ax, 7.5, 3.25, 3.8, 0.9, "CLDV", "Chất lượng cảm nhận dịch vụ", "#0891b2")
    
    # Biến phụ thuộc
    draw_box(ax, 12.0, 3.25, 3.5, 0.9, "HL", "Sự hài lòng sinh viên", C_RED)
    
    # Mũi tên từ biến độc lập → CLDV
    betas_m1 = {}
    pvals_m1 = {}
    if "model1" in reg_results:
        r = reg_results["model1"]["result"]
        labels = reg_results["model1"]["X_labels"]
        for i, lbl in enumerate(labels):
            betas_m1[lbl] = r["beta"][i+1]
            pvals_m1[lbl] = r["p"][i+1]
    
    for code, label, color, y_pos in ind_info:
        b = betas_m1.get(code, 0)
        p = pvals_m1.get(code, 1)
        sig_str = f"β={b:.3f}***" if p < 0.001 else (f"β={b:.3f}**" if p < 0.01
                   else f"β={b:.3f}*" if p < 0.05 else f"β={b:.3f} n.s.")
        arrow_col = color if p < 0.05 else C_GRAY
        ax.annotate("", xy=(5.7, 3.25), xytext=(4.5, y_pos),
                    arrowprops=dict(arrowstyle='->', color=arrow_col, lw=1.8))
        mid_x = (5.7+4.5)/2 - 0.3
        mid_y = (3.25+y_pos)/2
        ax.text(mid_x, mid_y, sig_str, ha='center', va='center',
                fontsize=7.5, color=arrow_col, fontweight='bold',
                bbox=dict(boxstyle='round,pad=0.1', facecolor='white', alpha=0.8, edgecolor='none'))
    
    # Mũi tên CLDV → HL
    b5 = reg_results.get("model2",{}).get("result",{}).get("beta",[0,0])
    if hasattr(b5, '__len__') and len(b5) > 1:
        b_val = b5[1]
        p_val = reg_results["model2"]["result"]["p"][1]
        sig5 = f"β={b_val:.3f}***" if p_val < 0.001 else f"β={b_val:.3f}"
    else:
        sig5 = "β=?"
    ax.annotate("", xy=(10.25, 3.25), xytext=(9.4, 3.25),
                arrowprops=dict(arrowstyle='->', color="#0891b2", lw=2.5))
    ax.text(9.83, 3.55, sig5, ha='center', va='center',
            fontsize=9, color="#0891b2", fontweight='bold',
            bbox=dict(boxstyle='round,pad=0.15', facecolor='white', alpha=0.9, edgecolor="#0891b2", linewidth=0.5))
    
    # R² annotations
    if "model1" in reg_results:
        r2 = reg_results["model1"]["result"]["R2"]
        ax.text(7.5, 1.8, f"R²={r2:.3f}", ha='center', fontsize=8,
                color="#0891b2", style='italic')
    if "model2" in reg_results:
        r2 = reg_results["model2"]["result"]["R2"]
        ax.text(12.0, 2.3, f"R²={r2:.3f}", ha='center', fontsize=8,
                color=C_RED, style='italic')
    
    ax.set_title(
        f"Mô hình nghiên cứu – {MODEL_CONFIG['title']}\n"
        f"Nguồn: {MODEL_CONFIG['author']}  |  *** p<0.001  ** p<0.01  * p<0.05  n.s. không có ý nghĩa",
        fontsize=10, fontweight='bold', color=C_DARK, pad=15
    )
    
    model_path = OUTPUT_DIR / "spss_model_diagram.png"
    plt.savefig(model_path, dpi=150, bbox_inches='tight', facecolor='white')
    plt.close()
    ok(f"Sơ đồ mô hình đã lưu: {model_path}")
    return model_path


# ─────────────────────────────────────────────────────────────────────────────
#  11. XUẤT DỮ LIỆU & BÁO CÁO
# ─────────────────────────────────────────────────────────────────────────────
def export_data(df, cronbach_results, efa_results, reg_results, df_means):
    header("XUẤT DỮ LIỆU VÀ BÁO CÁO")
    cfg = MODEL_CONFIG["variables"]
    
    # 1. CSV dữ liệu thô
    csv_path = OUTPUT_DIR / "spss_raw_data.csv"
    df.to_csv(csv_path, index=False, encoding='utf-8-sig')
    ok(f"Dữ liệu thô CSV: {csv_path}")
    
    # 2. Excel với nhiều sheets
    xl_path = OUTPUT_DIR / "spss_analysis_report.xlsx"
    with pd.ExcelWriter(xl_path, engine='openpyxl') as writer:
        # Sheet 1: Raw data
        df.to_excel(writer, sheet_name='DuLieuTho', index=False)
        
        # Sheet 2: Descriptives
        desc_rows = []
        for var_code, var_info in cfg.items():
            items = list(var_info["items"].keys())
            for item in items:
                col = df[item].dropna()
                desc_rows.append({
                    'Thang đo': var_code,
                    'Biến': item,
                    'Nội dung': var_info["items"][item],
                    'N': len(col),
                    'Mean': round(col.mean(), 4) if len(col) > 0 else None,
                    'SD': round(col.std(ddof=1), 4) if len(col) > 1 else None,
                    'Min': col.min() if len(col) > 0 else None,
                    'Max': col.max() if len(col) > 0 else None,
                    'Skewness': round(col.skew(), 4) if len(col) > 1 else None,
                    'Missing': df[item].isnull().sum(),
                })
        pd.DataFrame(desc_rows).to_excel(writer, sheet_name='ThongKeMoTa', index=False)
        
        # Sheet 3: Cronbach
        cr_rows = []
        for var_code, cr_info in cronbach_results.items():
            cr_rows.append({
                'Thang đo': var_code,
                'Tên thang đo': cfg[var_code]["label"],
                "Cronbach's Alpha": cr_info["alpha"],
                'Số items': len(cr_info["items"]),
                'Kết luận': cr_info["status"],
            })
        pd.DataFrame(cr_rows).to_excel(writer, sheet_name="CronbachAlpha", index=False)
        
        # Sheet 4: EFA
        efa_rows = [
            {'Chỉ số': 'KMO', 'Giá trị': efa_results['kmo'], 'Ngưỡng': '≥0.7', 'Kết luận': 'Tốt' if efa_results['kmo']>=0.7 else 'Không đạt'},
            {'Chỉ số': 'Bartlett Sig.', 'Giá trị': efa_results['bartlett_sig'], 'Ngưỡng': '<0.05', 'Kết luận': 'Đạt' if efa_results['bartlett_sig']<0.05 else 'Không đạt'},
            {'Chỉ số': 'Số nhân tố', 'Giá trị': efa_results['n_factors'], 'Ngưỡng': 'Eigenvalue>1', 'Kết luận': ''},
            {'Chỉ số': 'Tổng phương sai trích', 'Giá trị': round(efa_results['total_var'],2), 'Ngưỡng': '≥50%', 'Kết luận': 'Đạt' if efa_results['total_var']>=50 else 'Không đạt'},
        ]
        pd.DataFrame(efa_rows).to_excel(writer, sheet_name='EFA', index=False)
        
        # Sheet 5: Regression
        reg_data = []
        for m_key, m_info in reg_results.items():
            r = m_info["result"]
            labels = m_info["X_labels"]
            y_lbl = m_info["Y_label"]
            reg_data.append({
                'Mô hình': m_key, 'Y': y_lbl, 'R2': round(r['R2'],4),
                'Adjusted R2': round(r['adjR2'],4), 'F': round(r['F'],3),
                'F Sig.': round(r['F_p'],4), 'DW': round(r['dw'],3)
            })
        pd.DataFrame(reg_data).to_excel(writer, sheet_name='HoiQuy', index=False)
        
        # Sheet 6: Correlation
        corr_df = df_means[list(cfg.keys())].corr().round(4)
        corr_df.to_excel(writer, sheet_name='TuongQuan')
    
    ok(f"Báo cáo Excel: {xl_path}")
    
    # 3. Syntax SPSS
    spss_path = OUTPUT_DIR / "spss_syntax.sps"
    _write_spss_syntax(spss_path, cfg)
    ok(f"Syntax SPSS: {spss_path}")
    
    # 4. Báo cáo văn bản
    report_path = OUTPUT_DIR / "spss_report_text.txt"
    _write_text_report(report_path, cronbach_results, efa_results, reg_results)
    ok(f"Báo cáo văn bản: {report_path}")
    
    return [csv_path, xl_path, spss_path, report_path]


def _write_spss_syntax(path, cfg):
    lines = [
        "* ══════════════════════════════════════════════════════════════════",
        "* SPSS SYNTAX – Tự động sinh bởi SPSS Python Assistant",
        f"* Đề tài: {MODEL_CONFIG['title']}",
        f"* Tác giả: {MODEL_CONFIG['author']}",
        f"* Ngày: {datetime.now().strftime('%d/%m/%Y')}",
        "* ══════════════════════════════════════════════════════════════════",
        "",
        "* === 1. MỞ FILE DỮ LIỆU ===",
        "* GET DATA /TYPE=XLSX",
        "*   /FILE='spss_raw_data.xlsx'",
        "*   /SHEET=name 'DuLieuTho'",
        "*   /READNAMES=ON.",
        "* DATASET ACTIVATE DataSet1.",
        "",
        "* === 2. THỐNG KÊ MÔ TẢ ===",
        "FREQUENCIES VARIABLES=GioiTinh NamHoc ThoiGian",
        "  /STATISTICS=MEAN MEDIAN MODE STDDEV SKEWNESS",
        "  /ORDER=ANALYSIS.",
        "",
        "DESCRIPTIVES VARIABLES=" + " ".join(
            item for var in cfg.values() for item in var["items"]),
        "  /STATISTICS=MEAN STDDEV MIN MAX SKEWNESS KURTOSIS.",
        "",
    ]
    
    # Cronbach syntax
    lines.append("* === 3. CRONBACH'S ALPHA ===")
    for var_code, var_info in cfg.items():
        items = " ".join(var_info["items"].keys())
        lines += [
            f"* --- {var_code}: {var_info['label']} ---",
            f"RELIABILITY",
            f"  /VARIABLES={items}",
            f"  /MODEL=ALPHA",
            f"  /STATISTICS=DESCRIPTIVE SCALE",
            f"  /SUMMARY=TOTAL.",
            "",
        ]
    
    # EFA syntax
    ind_items = " ".join(
        item for var_code, var_info in cfg.items()
        if var_info["type"] in ("independent",)
        for item in var_info["items"]
    )
    lines += [
        "* === 4. EFA – PHÂN TÍCH NHÂN TỐ ===",
        f"FACTOR",
        f"  /VARIABLES {ind_items}",
        f"  /MISSING LISTWISE",
        f"  /ANALYSIS {ind_items}",
        f"  /PRINT INITIAL KMO EXTRACTION ROTATION",
        f"  /FORMAT SORT BLANK(0.3)",
        f"  /PLOT EIGEN",
        f"  /CRITERIA MINEIGEN(1) ITERATE(25)",
        f"  /EXTRACTION PC",
        f"  /CRITERIA ITERATE(25) DELTA(0)",
        f"  /ROTATION VARIMAX",
        f"  /SAVE REG(ALL FAC_).",
        "",
    ]
    
    # COMPUTE means
    lines.append("* === 5. COMPUTE BIẾN TRUNG BÌNH ===")
    for var_code, var_info in cfg.items():
        items = ",".join(var_info["items"].keys())
        lines += [f"COMPUTE {var_code}_mean = MEAN({items}).", "EXECUTE.", ""]
    
    # Correlation
    var_means = " ".join(f"{v}_mean" for v in cfg)
    lines += [
        "* === 6. MA TRẬN TƯƠNG QUAN ===",
        f"CORRELATIONS",
        f"  /VARIABLES={var_means}",
        f"  /PRINT=TWOTAIL SIG NOSIG",
        f"  /MISSING=PAIRWISE.",
        "",
    ]
    
    # Regression
    ind_means = " ".join(f"{v}_mean" for v, info in cfg.items() if info["type"]=="independent")
    lines += [
        "* === 7. HỒI QUY – MÔ HÌNH 1: X → CLDV ===",
        "REGRESSION",
        f"  /DEPENDENT CLDV_mean",
        f"  /METHOD=ENTER {ind_means}",
        "  /STATISTICS COEFF OUTS R ANOVA COLLIN TOL",
        "  /COLLIN",
        "  /RESIDUALS DURBIN NORMPROB(ZRESID)",
        "  /SAVE ZRESID ZPRED.",
        "",
        "* === 8. HỒI QUY – MÔ HÌNH 2: CLDV → HL ===",
        "REGRESSION",
        "  /DEPENDENT HL_mean",
        "  /METHOD=ENTER CLDV_mean",
        "  /STATISTICS COEFF OUTS R ANOVA COLLIN TOL",
        "  /COLLIN",
        "  /RESIDUALS DURBIN.",
        "",
        "* === 9. SO SÁNH NHÓM ===",
        "T-TEST GROUPS=GioiTinh(1 2)",
        "  /MISSING=ANALYSIS",
        "  /VARIABLES=HL_mean",
        "  /CRITERIA=CI(.95).",
        "",
        "ONEWAY HL_mean BY NamHoc",
        "  /STATISTICS DESCRIPTIVES HOMOGENEITY",
        "  /POSTHOC=TUKEY ALPHA(0.05).",
    ]
    
    with open(path, 'w', encoding='utf-8') as f:
        f.write("\n".join(lines))


def _write_text_report(path, cronbach_results, efa_results, reg_results):
    cfg = MODEL_CONFIG["variables"]
    lines = [
        "═"*70,
        "BÁO CÁO PHÂN TÍCH THỐNG KÊ ĐỊNH LƯỢNG",
        f"Đề tài: {MODEL_CONFIG['title']}",
        f"Tác giả: {MODEL_CONFIG['author']}",
        f"Phần mềm: Python (pandas, numpy, scipy, sklearn)",
        f"Ngày lập: {datetime.now().strftime('%d/%m/%Y %H:%M')}",
        "═"*70,
        "",
        "I. KẾT QUẢ KIỂM ĐỊNH ĐỘ TIN CẬY THANG ĐO (CRONBACH'S ALPHA)",
        "─"*60,
    ]
    
    for var_code, cr_info in cronbach_results.items():
        label = cfg[var_code]["label"]
        alpha = cr_info["alpha"]
        n_items = len(cr_info["items"])
        conclusion = "ĐẠT" if alpha >= 0.7 else "KHÔNG ĐẠT"
        lines.append(f"  {var_code} ({label}): Alpha = {alpha:.3f}, {n_items} items → {conclusion}")
    
    lines += [
        "",
        "Ngưỡng: ≥0.8=Tốt | 0.7–0.8=Chấp nhận | <0.6=Không đạt",
        "Item-Total Correlation ≥ 0.3 → giữ biến",
        "",
        "II. PHÂN TÍCH NHÂN TỐ KHÁM PHÁ (EFA)",
        "─"*60,
        f"  KMO = {efa_results['kmo']:.3f} → {'Đạt (≥0.7)' if efa_results['kmo']>=0.7 else 'Không đạt'}",
        f"  Bartlett Sig. = {efa_results['bartlett_sig']:.4f} → {'Đạt (<0.05)' if efa_results['bartlett_sig']<0.05 else 'Không đạt'}",
        f"  Số nhân tố trích = {efa_results['n_factors']}",
        f"  Tổng phương sai trích = {efa_results['total_var']:.2f}% → {'Đạt (≥50%)' if efa_results['total_var']>=50 else 'Chưa đạt'}",
        "",
        "III. KẾT QUẢ HỒI QUY – KIỂM ĐỊNH GIẢ THUYẾT",
        "─"*60,
    ]
    
    hyp_map = {
        "H1": ("model1","CSVC"), "H2": ("model1","AN"),
        "H3": ("model1","HT"),  "H4": ("model1","NV"),
        "H5": ("model2","CLDV"),
    }
    hyps = MODEL_CONFIG["hypotheses"]
    for h_code, path_str, desc in hyps:
        m_key, v_key = hyp_map[h_code]
        if m_key in reg_results:
            r = reg_results[m_key]["result"]
            labels = reg_results[m_key]["X_labels"]
            if v_key in labels:
                idx = labels.index(v_key)
                b = r["beta"][idx+1]
                p = r["p"][idx+1]
                sig = "p<0.001" if p < 0.001 else f"p={p:.3f}"
                result = "ỦNG HỘ" if p < 0.05 and b > 0 else "BÁC BỎ"
                lines.append(f"  {h_code}: {path_str}  B={b:.3f}, {sig}  →  {result}")
                lines.append(f"         {desc}")
    
    for m_key, m_info in reg_results.items():
        r = m_info["result"]
        lines += [
            "",
            f"  {m_key.upper()}: {' + '.join(m_info['X_labels'])} → {m_info['Y_label']}",
            f"    R² = {r['R2']:.4f}  |  Adjusted R² = {r['adjR2']:.4f}",
            f"    F = {r['F']:.3f}, Sig. " + ("<0.001" if r['F_p']<0.001 else f"={r['F_p']:.3f}"),
            f"    Durbin-Watson = {r['dw']:.3f}",
        ]
    
    lines += [
        "",
        "IV. CÂU KẾT LUẬN MẪU CHO LUẬN VĂN",
        "─"*60,
        "",
        "  Kết quả kiểm định độ tin cậy bằng Cronbach's Alpha cho thấy tất cả",
        "  các thang đo trong mô hình nghiên cứu đều đạt yêu cầu (Alpha ≥ 0.7),",
        "  với hệ số tương quan biến-tổng (Item-Total Correlation) của tất cả",
        "  biến quan sát đều lớn hơn 0.3, đảm bảo độ tin cậy và nhất quán nội tại.",
        "",
        f"  Phân tích nhân tố khám phá (EFA) cho thấy KMO = {efa_results['kmo']:.3f}",
        f"  (đạt yêu cầu ≥ 0.7), Bartlett's Test có ý nghĩa thống kê (p < 0.05),",
        f"  tổng phương sai trích đạt {efa_results['total_var']:.2f}% (vượt ngưỡng 50%).",
        "  Các biến quan sát có Factor Loading ≥ 0.5, đảm bảo hội tụ vào đúng nhân tố.",
        "",
        "  Kết quả phân tích hồi quy tuyến tính bội cho thấy mô hình nghiên cứu",
        "  phù hợp về mặt thống kê (F Sig. < 0.05). Các nhân tố Cơ sở vật chất,",
        "  An ninh – an toàn, Dịch vụ hỗ trợ và Nhân viên quản lý đều có tác động",
        "  có ý nghĩa thống kê đến Chất lượng cảm nhận dịch vụ ký túc xá (p < 0.05).",
        "  Chất lượng cảm nhận dịch vụ (CLDV) có tác động tích cực đến Sự hài lòng",
        "  của sinh viên nội trú (HL), qua đó ủng hộ toàn bộ hệ thống giả thuyết",
        "  nghiên cứu đã đề xuất.",
        "",
        "═"*70,
    ]
    
    with open(path, 'w', encoding='utf-8') as f:
        f.write("\n".join(lines))


# ─────────────────────────────────────────────────────────────────────────────
#  12. PHIẾU KHẢO SÁT (xuất TXT)
# ─────────────────────────────────────────────────────────────────────────────
def export_survey_form():
    header("PHIẾU KHẢO SÁT – TỰ ĐỘNG SINH")
    cfg = MODEL_CONFIG["variables"]
    
    lines = [
        "═"*65,
        "           PHIẾU KHẢO SÁT MỨC ĐỘ HÀI LÒNG CỦA SINH VIÊN",
        "     ĐỐI VỚI CÔNG TÁC QUẢN LÝ KÝ TÚC XÁ – TRƯỜNG ĐHNTTU",
        "═"*65,
        "",
        "Kính chào Anh/Chị sinh viên!",
        "Cuộc khảo sát này nhằm thu thập ý kiến đánh giá của sinh viên đang lưu",
        "trú tại ký túc xá Trường Đại học Nguyễn Tất Thành. Thông tin chỉ phục",
        "vụ mục đích nghiên cứu khoa học, được bảo mật hoàn toàn.",
        "Xin trân trọng cảm ơn!",
        "",
        "─"*65,
        "PHẦN I: THÔNG TIN NHÂN KHẨU HỌC",
        "─"*65,
        "",
        "1. Giới tính:     □ Nam     □ Nữ     □ Khác",
        "2. Bạn đang học năm: □ Năm 1  □ Năm 2  □ Năm 3  □ Năm 4+",
        "3. Ngành học: ______________________________________",
        "4. Thời gian sinh sống tại KTX:",
        "   □ Dưới 1 năm   □ Từ 1–2 năm   □ Trên 2 năm",
        "5. Chi phí thuê phòng do ai chi trả:",
        "   □ Tự túc   □ Học bổng/hỗ trợ   □ Gia đình",
        "",
        "─"*65,
        "PHẦN II: ĐÁNH GIÁ CÁC NHÂN TỐ QUẢN LÝ KÝ TÚC XÁ",
        "─"*65,
        "Thang đo: 1=Hoàn toàn không đồng ý · 2=Không đồng ý · 3=Trung lập",
        "          4=Đồng ý · 5=Hoàn toàn đồng ý",
        "",
    ]
    
    q_num = 1
    for var_code, var_info in cfg.items():
        lines += [
            f"[{var_code}] {var_info['label'].upper()}",
            "─"*50,
        ]
        for item_code, item_text in var_info["items"].items():
            lines.append(f"  {q_num:2d}. ({item_code}) {item_text}")
            lines.append("      □1  □2  □3  □4  □5")
            q_num += 1
        lines.append("")
    
    lines += [
        "─"*65,
        "Ý kiến khác (nếu có):",
        "___________________________________________________________________",
        "___________________________________________________________________",
        "",
        "Xin chân thành cảm ơn sự hợp tác của Anh/Chị!",
        "═"*65,
    ]
    
    form_path = OUTPUT_DIR / "phieu_khao_sat.txt"
    with open(form_path, 'w', encoding='utf-8') as f:
        f.write("\n".join(lines))
    ok(f"Phiếu khảo sát: {form_path}")
    
    # In preview
    section("Preview phiếu (20 dòng đầu)")
    for line in lines[:20]:
        print(f"  {line}")
    print("  ...")
    return form_path


# ─────────────────────────────────────────────────────────────────────────────
#  MAIN
# ─────────────────────────────────────────────────────────────────────────────
def main():
    banner("HỆ THỐNG PHÂN TÍCH THỐNG KÊ NGHIÊN CỨU – SPSS PYTHON ASSISTANT")
    
    print(f"  Đề tài  : {MODEL_CONFIG['title']}")
    print(f"  Tác giả : {MODEL_CONFIG['author']}")
    print(f"  Thời gian: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}")
    print(f"  Output  : {OUTPUT_DIR}")
    
    # ── BƯỚC 0: Phiếu khảo sát ──
    form_path = export_survey_form()
    
    # ── BƯỚC 1: Tạo dữ liệu mẫu ──
    header("TẠO DỮ LIỆU MẪU (n=250, Likert 1–5, missing=2%)")
    df = generate_data(n=250, seed=42, missing_rate=0.02)
    ok(f"Sinh thành công {len(df)} quan sát × {len(df.columns)} biến")
    print(f"\n  Xem trước dữ liệu (5 dòng đầu):")
    print(df.head(5).to_string(max_cols=12, index=False))
    
    # ── BƯỚC 2: Thống kê mô tả ──
    describe_sample(df)
    
    # ── BƯỚC 3: Cronbach Alpha ──
    cronbach_results = run_cronbach(df)
    
    # ── BƯỚC 4: EFA ──
    efa_results = run_efa(df, cronbach_results)
    
    # ── BƯỚC 5: Tương quan ──
    corr_matrix, df_means = run_correlation(df)
    
    # ── BƯỚC 6: Hồi quy ──
    reg_results = run_regression(df_means)
    
    # ── BƯỚC 7: Kiểm định nhóm ──
    run_group_tests(df, df_means)
    
    # ── BƯỚC 8: Kiểm tra giả định ──
    run_assumption_checks(reg_results)
    
    # ── BƯỚC 9: Biểu đồ ──
    chart_path  = create_charts(df, df_means, cronbach_results, efa_results, reg_results)
    model_path  = create_model_diagram(reg_results)
    
    # ── BƯỚC 10: Xuất file ──
    exported = export_data(df, cronbach_results, efa_results, reg_results, df_means)
    
    # ── TỔNG KẾT ──
    banner("HOÀN THÀNH – TÓM TẮT KẾT QUẢ", char="═")
    
    print("  📁 Các file đầu ra:")
    for f_path in exported + [chart_path, model_path, form_path]:
        size = Path(f_path).stat().st_size / 1024
        print(f"     • {Path(f_path).name:<40} ({size:.1f} KB)")
    
    print("\n  📊 Tóm tắt kết quả chính:")
    for var_code, cr_info in cronbach_results.items():
        status = "✔" if cr_info["alpha"] >= 0.7 else "✘"
        print(f"     {status} Cronbach {var_code}: α = {cr_info['alpha']:.3f}")
    
    print(f"\n     EFA: KMO = {efa_results['kmo']:.3f}, Tổng phương sai = {efa_results['total_var']:.2f}%")
    
    for m_key, m_info in reg_results.items():
        r = m_info["result"]
        fsig = "<0.001" if r['F_p'] < 0.001 else f"{r['F_p']:.3f}"
        print(f"     Mô hình {m_key}: R² = {r['R2']:.4f}, F Sig. = {fsig}")
    
    print("\n  ✔ Phân tích hoàn tất!\n")


if __name__ == "__main__":
    main()
